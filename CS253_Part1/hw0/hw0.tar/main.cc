        #include <iostream>
        using namespace std;

        int main() {
            // How many psychologists does it take to change a light bulb?
            cout << "One but the lightbulb really has to want to change \n";
            return 0;
        }
