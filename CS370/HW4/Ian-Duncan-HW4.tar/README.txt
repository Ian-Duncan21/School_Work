1. Is the Shortest Remaining Time First a non-preemptive Algorithm?
    It is preemptive
2. What are the 5 different states a process can be in scheduling (Look into process state
diagram)?
    new, ready, running, Waiting, terminated
3. Shortest Job First is like Priority Scheduling with the priority based on ______ of the process?
    remaining burst time
4. ________ effect is the primary disadvantage of First Come First Serve Scheduling algorithm.
    Convoy
5. How does Multi Level Feedback queue prevent starvation of processes that waits too long in
lower priority queue?
    Processes which wait too long in a lower priorty queue can be moved to a higher priority queue,
    but if a process takes up too much time it will be pushed to the end of the queue
