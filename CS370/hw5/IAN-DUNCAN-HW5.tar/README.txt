README
======

This package includes the following files.

|-- Coordinator.java [Description Here] (Skeleton Code provided)
|-- Generator.java [Description Here] (Skeleton Code provided)
|-- Consumer.java [Description Here]
|-- Buffer.java [Description Here]
|-- Makefile [Description Here]
|-- README.txt [This file]


Questions:

1. The problem of producer consumer is solved using __________. - 1 point
	a. Mutex Locks
	b. Semaphores

2. What two functions defined in Java are used for synchronization between producer and consumers in your program? __________ and __________. - 2 points
    wait(), notify()
3. In which function do you override the body to define the new body of a thread in java? __________. - 1 point
    start()
4. Which function is used to wait for a thread to finish and come back to calling program i.e. for a thread to die? __________. - 1 point
    join()

NOTE:

Lab systems by default use Java 11 which supports nanosecond timestamp. If after logging in and running 'java -version', it doesn't output version 11, use the following two commands:

	$ export PATH=/usr/lib/jvm/jre-11-openjdk/bin/:$PATH

	$ export LD_LIBRARY_PATH=/usr/lib/jvm/jre-11-openjdk/lib/:$LD_LIBRARY_PATH
