int random_in_range(int, int);

int get_prime_count(int *, int);

float get_running_ratio();

